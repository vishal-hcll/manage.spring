package com.Employee.Management.Controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Employee.Management.Entity.Employee;
import com.Employee.Management.Repository.EmployeeRepository;

@RestController

@RequestMapping("api/employees")
public class EmployeeController 
{
	
	
	
	EmployeeRepository er=new EmployeeRepository();


	
	// to get all employees
	
	@GetMapping
	public ResponseEntity<?> getAllEmployees(){
	
		return ResponseEntity.ok(er.getAllEmployee());
		

	}
//////////////////////////////////////////////////////////////////////////////
	
	
	// create employee nd save in database
	
	@PostMapping
	public ResponseEntity create(@RequestBody Employee emp)
	{
		er.save(emp);
		return ResponseEntity.ok(emp);
	}
	
	///////////////////////////////////////////////////////////////////////////////
	
	
	// update employee
	
	@PutMapping("{id}")
	public ResponseEntity update(@PathVariable int id, @RequestBody Employee emp)
	{
		
		er.updateEmp(id, emp);
		return ResponseEntity.ok(emp);
	}
	//////////////////////////////////////////////////////////////////////////////////////

	
	// get employee by id
	
	@GetMapping("{id}")
	public ResponseEntity getById(@PathVariable int id)
	{
		
		return ResponseEntity.ok(er.getEmployee(id));
	}
	
	
	/////////////////////////////////////////////////////////////////////////////////////////
	
		// delete employee
	
	
	@DeleteMapping("{id}")
	public ResponseEntity Delete(@PathVariable int id)
	{
		
	er.deleteEmployee(id);
	
	return new ResponseEntity(HttpStatus.NO_CONTENT);
	}
	
	
}
