package com.Employee.Management.Entity;

import java.sql.Connection;
import java.sql.DriverManager;

public class Db {
	
static Connection con;
	
	public static Connection create()
	{
		try {
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			String url="jdbc:mysql://localhost:3306/EmpManage";
			
			String user="root";
			
			String pass="mysql";
			
				con=DriverManager.getConnection(url,user, pass);
				
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
			
			e.printStackTrace();
		}
		
		return con;
	}

}
