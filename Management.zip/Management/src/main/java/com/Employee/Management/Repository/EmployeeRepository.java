package com.Employee.Management.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.Employee.Management.Entity.Db;
import com.Employee.Management.Entity.Employee;

@Repository
public class EmployeeRepository {

	
Connection con=Db.create();
	
	
	
    public List<Employee> getAllEmployee() {
    	
        List<Employee> emp = new ArrayList<>();
        
        try {
        	
        	
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("SELECT * FROM employee");
			
			
			while(rs.next())
			{
				Employee e =new Employee();
				
				e.setId(rs.getInt(1));
				
				e.setFirstName(rs.getString(2));
				
				e.setLastName(rs.getString(3));
				
				
				e.setDepartment(rs.getString(4));
				
				e.setAddress(rs.getString(5));
				
				e.setEmail(rs.getString(6));
				
				emp.add(e);
			}
			
			rs.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        
        return emp;
        
    }
    
    
 /////////////////////////////////////////////////////////////   
    
    
    public void save(Employee emp)
    {
    	String q="insert into employee (fname,lname,department,address,email) values (?,?,?,?,?)";
    	
    	try {
    		
    	
			PreparedStatement pstmt =con.prepareStatement(q);
			
			pstmt.setString(1, emp.getFirstName());
			pstmt.setString(2, emp.getLastName());
			pstmt.setString(3, emp.getDepartment());
			pstmt.setString(4, emp.getAddress());
			pstmt.setString(5, emp.getEmail());
			
			
			pstmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    }
    
    
    
///////////////////////////////////////////////////////////////////////
    
    
    
    public void updateEmp(int id, Employee emp)
    {
    	
    	String q="update employee set fname=?,lname=?,department=?,address=?,email=? where id =?";
    	
    	try {
			PreparedStatement pstmt=con.prepareStatement(q);
			
			pstmt.setString(1, emp.getFirstName());

			pstmt.setString(2, emp.getLastName());
			pstmt.setString(3, emp.getDepartment());
			
			pstmt.setString(4, emp.getAddress());
			
			pstmt.setString(5, emp.getEmail());
			
			pstmt.setInt(6, id);
			
			
			pstmt.execute();
    	
    	} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    }
    
    
    
    
    public Employee getEmployee(int id)
    {
    	Employee e =new Employee();
    	String q="select * from employee where id=?";
    	
    	try
    	{
    	
    	PreparedStatement pstmt=con.prepareStatement(q);
    	
		pstmt.setInt(1, id);
		
		ResultSet rs=pstmt.executeQuery();
		
		
		
		while(rs.next())
		{
			
			
			e.setId(rs.getInt(1));
			
			e.setFirstName(rs.getString(2));
			
			e.setLastName(rs.getString(3));
			
			
			e.setDepartment(rs.getString(4));
			
			e.setAddress(rs.getString(5));
			
			e.setEmail(rs.getString(6));
			
			
		}
		
		rs.close();
    	}
    	catch(Exception ex)
    	{
    		ex.printStackTrace();
    	}
    	
    	
    	return e;
    	
    }
    
    
    public void deleteEmployee(int id)
    {
    	
    	
    	String q="delete from employee where id=?";
    	
    	try {
    		
			PreparedStatement pstmt=con.prepareStatement(q);
			
			pstmt.setInt(1, id);
			
			pstmt.execute();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    
    
    
    
    

}
